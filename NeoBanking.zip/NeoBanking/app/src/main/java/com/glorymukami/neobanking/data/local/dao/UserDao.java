package com.glorymukami.neobanking.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.glorymukami.neobanking.data.local.entities.User;

/**
 * Data Access Object for User entity
 */
@Dao
public interface UserDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(User user);

    @Update
    void update(User user);

    @Delete
    void delete(User user);

    @Query("SELECT * FROM users LIMIT 1")
    LiveData<User> getCurrentUser();

    @Query("SELECT * FROM users WHERE id = :userId")
    LiveData<User> getUserById(long userId);

    @Query("SELECT * FROM users WHERE email = :email LIMIT 1")
    LiveData<User> getUserByEmail(String email);

    @Query("UPDATE users SET biometric_enabled = :enabled WHERE id = :userId")
    void updateBiometricEnabled(long userId, boolean enabled);

    @Query("UPDATE users SET theme_mode = :themeMode WHERE id = :userId")
    void updateThemeMode(long userId, String themeMode);

    @Query("UPDATE users SET notifications_enabled = :enabled WHERE id = :userId")
    void updateNotificationsEnabled(long userId, boolean enabled);

    @Query("DELETE FROM users")
    void deleteAll();

    @Query("SELECT COUNT(*) FROM users")
    int getUserCount();
}