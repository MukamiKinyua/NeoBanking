package com.glorymukami.neobanking.data.local.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.TypeConverters;
import com.glorymukami.neobanking.data.local.Converters;
import java.util.Date;

/**
 * Account entity for Room database
 * Stores linked bank accounts from Plaid
 */
@Entity(tableName = "accounts")
@TypeConverters(Converters.class)
public class Account {

    @PrimaryKey(autoGenerate = true)
    private long id;

    @ColumnInfo(name = "plaid_account_id")
    private String plaidAccountId;

    @ColumnInfo(name = "plaid_item_id")
    private String plaidItemId;

    @ColumnInfo(name = "account_name")
    private String accountName;

    @ColumnInfo(name = "official_name")
    private String officialName;

    @ColumnInfo(name = "account_type") // checking, savings, credit
    private String accountType;

    @ColumnInfo(name = "account_subtype")
    private String accountSubtype;

    @ColumnInfo(name = "mask") // Last 4 digits
    private String mask;

    @ColumnInfo(name = "current_balance")
    private double currentBalance;

    @ColumnInfo(name = "available_balance")
    private double availableBalance;

    @ColumnInfo(name = "currency")
    private String currency;

    @ColumnInfo(name = "institution_name")
    private String institutionName;

    @ColumnInfo(name = "institution_id")
    private String institutionId;

    @ColumnInfo(name = "is_active")
    private boolean isActive;

    @ColumnInfo(name = "last_synced")
    private Date lastSynced;

    @ColumnInfo(name = "created_at")
    private Date createdAt;

    @ColumnInfo(name = "updated_at")
    private Date updatedAt;

    // Constructor
    public Account() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
        this.isActive = true;
        this.currency = "USD";
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getPlaidAccountId() {
        return plaidAccountId;
    }

    public void setPlaidAccountId(String plaidAccountId) {
        this.plaidAccountId = plaidAccountId;
    }

    public String getPlaidItemId() {
        return plaidItemId;
    }

    public void setPlaidItemId(String plaidItemId) {
        this.plaidItemId = plaidItemId;
    }

    public String getAccountName() {
        return accountName;
    }

    public void setAccountName(String accountName) {
        this.accountName = accountName;
    }

    public String getOfficialName() {
        return officialName;
    }

    public void setOfficialName(String officialName) {
        this.officialName = officialName;
    }

    public String getAccountType() {
        return accountType;
    }

    public void setAccountType(String accountType) {
        this.accountType = accountType;
    }

    public String getAccountSubtype() {
        return accountSubtype;
    }

    public void setAccountSubtype(String accountSubtype) {
        this.accountSubtype = accountSubtype;
    }

    public String getMask() {
        return mask;
    }

    public void setMask(String mask) {
        this.mask = mask;
    }

    public double getCurrentBalance() {
        return currentBalance;
    }

    public void setCurrentBalance(double currentBalance) {
        this.currentBalance = currentBalance;
    }

    public double getAvailableBalance() {
        return availableBalance;
    }

    public void setAvailableBalance(double availableBalance) {
        this.availableBalance = availableBalance;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getInstitutionName() {
        return institutionName;
    }

    public void setInstitutionName(String institutionName) {
        this.institutionName = institutionName;
    }

    public String getInstitutionId() {
        return institutionId;
    }

    public void setInstitutionId(String institutionId) {
        this.institutionId = institutionId;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Date getLastSynced() {
        return lastSynced;
    }

    public void setLastSynced(Date lastSynced) {
        this.lastSynced = lastSynced;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}