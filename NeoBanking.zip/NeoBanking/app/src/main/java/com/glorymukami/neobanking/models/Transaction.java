package com.glorymukami.neobanking.models;

public class Transaction {
    private String id;
    private String title;
    private String category;
    private double amount;
    private String type; // "income" or "expense"
    private String date;
    private String description;

    public Transaction(String id, String title, String category, double amount, String type, String date, String description) {
        this.id = id;
        this.title = title;
        this.category = category;
        this.amount = amount;
        this.type = type;
        this.date = date;
        this.description = description;
    }

    // Getters
    public String getId() { return id; }
    public String getTitle() { return title; }
    public String getCategory() { return category; }
    public double getAmount() { return amount; }
    public String getType() { return type; }
    public String getDate() { return date; }
    public String getDescription() { return description; }

    public boolean isIncome() {
        return "income".equalsIgnoreCase(type);
    }

    public boolean isExpense() {
        return "expense".equalsIgnoreCase(type);
    }
}