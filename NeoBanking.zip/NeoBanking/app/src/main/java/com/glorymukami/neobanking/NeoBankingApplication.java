package com.glorymukami.neobanking;

import android.app.Application;
import androidx.work.Configuration;
import androidx.work.WorkManager;
import com.glorymukami.neobanking.data.local.AppDatabase;
import com.glorymukami.neobanking.utils.ThemeManager;

/**
 * Main Application class for NeoBanking
 * Initializes core components when the app starts
 */
public class NeoBankingApplication extends Application {

    private static NeoBankingApplication instance;
    private AppDatabase database;
    private ThemeManager themeManager;

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;

        // Initialize Room Database
        database = AppDatabase.getInstance(this);

        // Initialize Theme Manager
        themeManager = new ThemeManager(this);

        // Initialize WorkManager for background tasks
        initializeWorkManager();
    }

    private void initializeWorkManager() {
        Configuration config = new Configuration.Builder()
                .setMinimumLoggingLevel(android.util.Log.INFO)
                .build();
        WorkManager.initialize(this, config);
    }

    public static NeoBankingApplication getInstance() {
        return instance;
    }

    public AppDatabase getDatabase() {
        return database;
    }

    public ThemeManager getThemeManager() {
        return themeManager;
    }
}