package com.glorymukami.neobanking.ui.settings;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.utils.SecureStorage;

public class ChangePasswordActivity extends AppCompatActivity {

    private EditText currentPasswordInput;
    private EditText newPasswordInput;
    private EditText confirmPasswordInput;
    private Button saveButton;
    private SecureStorage secureStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Change Password");
        }

        initViews();
        setupListeners();
    }

    private void initViews() {
        currentPasswordInput = findViewById(R.id.current_password_input);
        newPasswordInput = findViewById(R.id.new_password_input);
        confirmPasswordInput = findViewById(R.id.confirm_password_input);
        saveButton = findViewById(R.id.save_button);

        try {
            secureStorage = new SecureStorage(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupListeners() {
        saveButton.setOnClickListener(v -> handlePasswordChange());
    }

    private void handlePasswordChange() {
        String currentPassword = currentPasswordInput.getText().toString().trim();
        String newPassword = newPasswordInput.getText().toString().trim();
        String confirmPassword = confirmPasswordInput.getText().toString().trim();

        // Validate current password
        if (currentPassword.isEmpty()) {
            currentPasswordInput.setError("Current password is required");
            Toast.makeText(this, "❌ Please enter current password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verify current password
        if (secureStorage != null) {
            try {
                String storedPassword = secureStorage.getString("registered_password", "");
                if (!storedPassword.isEmpty() && !currentPassword.equals(storedPassword)) {
                    currentPasswordInput.setError("Incorrect current password");
                    Toast.makeText(this, "❌ Current password is incorrect", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Validate new password
        if (newPassword.isEmpty()) {
            newPasswordInput.setError("New password is required");
            Toast.makeText(this, "❌ Please enter new password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (newPassword.length() < 6) {
            newPasswordInput.setError("Password must be at least 6 characters");
            Toast.makeText(this, "❌ Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (newPassword.equals(currentPassword)) {
            newPasswordInput.setError("New password must be different");
            Toast.makeText(this, "❌ New password must be different from current", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate confirm password
        if (confirmPassword.isEmpty()) {
            confirmPasswordInput.setError("Please confirm new password");
            Toast.makeText(this, "❌ Please confirm new password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!newPassword.equals(confirmPassword)) {
            confirmPasswordInput.setError("Passwords do not match");
            Toast.makeText(this, "❌ Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save new password
        if (secureStorage != null) {
            try {
                secureStorage.saveString("registered_password", newPassword);
                Toast.makeText(this, "✅ Password changed successfully!", Toast.LENGTH_LONG).show();
                finish();
            } catch (Exception e) {
                Toast.makeText(this, "❌ Error saving password: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "✅ Password changed successfully!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}