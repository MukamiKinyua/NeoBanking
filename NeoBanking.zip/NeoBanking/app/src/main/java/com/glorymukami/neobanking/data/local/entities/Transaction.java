package com.glorymukami.neobanking.data.local.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.TypeConverters;
import com.glorymukami.neobanking.data.local.Converters;
import java.util.Date;

/**
 * Transaction entity for Room database
 * Stores all transaction data offline-first
 */
@Entity(tableName = "transactions")
@TypeConverters(Converters.class)
public class Transaction {

    @PrimaryKey(autoGenerate = true)
    private long id;

    @ColumnInfo(name = "external_id")
    private String externalId; // ID from Plaid or API

    @ColumnInfo(name = "account_id")
    private String accountId;

    @ColumnInfo(name = "amount")
    private double amount;

    @ColumnInfo(name = "currency")
    private String currency;

    @ColumnInfo(name = "description")
    private String description;

    @ColumnInfo(name = "merchant_name")
    private String merchantName;

    @ColumnInfo(name = "category")
    private String category; // Auto-categorized

    @ColumnInfo(name = "category_confidence")
    private float categoryConfidence; // ML prediction confidence

    @ColumnInfo(name = "date")
    private Date date;

    @ColumnInfo(name = "is_pending")
    private boolean isPending;

    @ColumnInfo(name = "type") // DEBIT or CREDIT
    private String type;

    @ColumnInfo(name = "synced")
    private boolean synced; // For offline-first sync

    @ColumnInfo(name = "created_at")
    private Date createdAt;

    @ColumnInfo(name = "updated_at")
    private Date updatedAt;

    // Constructors
    public Transaction() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
        this.synced = false;
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getExternalId() {
        return externalId;
    }

    public void setExternalId(String externalId) {
        this.externalId = externalId;
    }

    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getMerchantName() {
        return merchantName;
    }

    public void setMerchantName(String merchantName) {
        this.merchantName = merchantName;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public float getCategoryConfidence() {
        return categoryConfidence;
    }

    public void setCategoryConfidence(float categoryConfidence) {
        this.categoryConfidence = categoryConfidence;
    }

    public Date getDate() {
        return date;
    }

    public void setDate(Date date) {
        this.date = date;
    }

    public boolean isPending() {
        return isPending;
    }

    public void setPending(boolean pending) {
        isPending = pending;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public boolean isSynced() {
        return synced;
    }

    public void setSynced(boolean synced) {
        this.synced = synced;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}