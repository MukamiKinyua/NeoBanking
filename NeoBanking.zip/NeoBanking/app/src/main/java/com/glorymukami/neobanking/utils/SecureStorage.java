package com.glorymukami.neobanking.utils;

import android.content.Context;
import android.content.SharedPreferences;
import android.util.Log;
import androidx.security.crypto.EncryptedSharedPreferences;
import androidx.security.crypto.MasterKey;
import java.io.IOException;
import java.security.GeneralSecurityException;

/**
 * Secure storage using Android's EncryptedSharedPreferences
 * Hardware-backed encryption for sensitive data
 */
public class SecureStorage {

    private static final String TAG = "SecureStorage";
    private static final String SECURE_PREFS_NAME = "secure_preferences";

    private SharedPreferences securePrefs;
    private Context context;

    public SecureStorage(Context context) {
        this.context = context;
        initializeSecurePreferences();
    }

    /**
     * Initialize encrypted shared preferences
     */
    private void initializeSecurePreferences() {
        try {
            MasterKey masterKey = new MasterKey.Builder(context)
                    .setKeyScheme(MasterKey.KeyScheme.AES256_GCM)
                    .build();

            securePrefs = EncryptedSharedPreferences.create(
                    context,
                    SECURE_PREFS_NAME,
                    masterKey,
                    EncryptedSharedPreferences.PrefKeyEncryptionScheme.AES256_SIV,
                    EncryptedSharedPreferences.PrefValueEncryptionScheme.AES256_GCM
            );

            Log.d(TAG, "Secure preferences initialized");
        } catch (GeneralSecurityException | IOException e) {
            Log.e(TAG, "Error initializing secure preferences", e);
            // Fallback to regular SharedPreferences (not recommended for production)
            securePrefs = context.getSharedPreferences(SECURE_PREFS_NAME, Context.MODE_PRIVATE);
        }
    }

    /**
     * Save encrypted string
     */
    public void saveString(String key, String value) {
        securePrefs.edit().putString(key, value).apply();
    }

    /**
     * Get encrypted string
     */
    public String getString(String key, String defaultValue) {
        return securePrefs.getString(key, defaultValue);
    }

    /**
     * Save boolean
     */
    public void saveBoolean(String key, boolean value) {
        securePrefs.edit().putBoolean(key, value).apply();
    }

    /**
     * Get boolean
     */
    public boolean getBoolean(String key, boolean defaultValue) {
        return securePrefs.getBoolean(key, defaultValue);
    }

    /**
     * Save integer
     */
    public void saveInt(String key, int value) {
        securePrefs.edit().putInt(key, value).apply();
    }

    /**
     * Get integer
     */
    public int getInt(String key, int defaultValue) {
        return securePrefs.getInt(key, defaultValue);
    }

    /**
     * Save long
     */
    public void saveLong(String key, long value) {
        securePrefs.edit().putLong(key, value).apply();
    }

    /**
     * Get long
     */
    public long getLong(String key, long defaultValue) {
        return securePrefs.getLong(key, defaultValue);
    }

    /**
     * Remove a key
     */
    public void remove(String key) {
        securePrefs.edit().remove(key).apply();
    }

    /**
     * Clear all data
     */
    public void clear() {
        securePrefs.edit().clear().apply();
    }

    /**
     * Check if key exists
     */
    public boolean contains(String key) {
        return securePrefs.contains(key);
    }

    // Common keys
    public static final String KEY_AUTH_TOKEN = "auth_token";
    public static final String KEY_USER_ID = "user_id";
    public static final String KEY_PLAID_ACCESS_TOKEN = "plaid_access_token";
    public static final String KEY_BIOMETRIC_ENABLED = "biometric_enabled";
    public static final String KEY_IS_LOGGED_IN = "is_logged_in";
}