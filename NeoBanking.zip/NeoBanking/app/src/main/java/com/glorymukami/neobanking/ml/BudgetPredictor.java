package com.glorymukami.neobanking.ml;

import android.content.Context;
import android.util.Log;
import com.glorymukami.neobanking.data.local.entities.Budget;
import com.glorymukami.neobanking.data.local.entities.Transaction;
import java.util.Calendar;
import java.util.Date;
import java.util.List;

/**
 * ML-based budget prediction
 * Predicts future spending based on historical data
 * In production, this would use TensorFlow Lite model
 */
public class BudgetPredictor {

    private static final String TAG = "BudgetPredictor";
    private Context context;

    public BudgetPredictor(Context context) {
        this.context = context;
    }

    /**
     * Predict spending for a category based on historical transactions
     * Uses simple moving average for demo (in production, use ML model)
     */
    public PredictionResult predictSpending(String category, List<Transaction> historicalTransactions) {
        if (historicalTransactions == null || historicalTransactions.isEmpty()) {
            return new PredictionResult(0.0, 0.0f);
        }

        // Calculate average spending for last 3 months
        Calendar cal = Calendar.getInstance();
        cal.add(Calendar.MONTH, -3);
        Date threeMonthsAgo = cal.getTime();

        double totalSpending = 0.0;
        int monthCount = 0;

        // Group by month and calculate average
        for (Transaction transaction : historicalTransactions) {
            if (transaction.getDate().after(threeMonthsAgo) &&
                    transaction.getCategory().equals(category)) {
                totalSpending += Math.abs(transaction.getAmount());
                monthCount++;
            }
        }

        // Calculate prediction
        double predictedSpending = monthCount > 0 ? totalSpending / 3.0 : 0.0;

        // Calculate confidence based on data availability
        float confidence = Math.min((float) monthCount / 30.0f, 1.0f);

        // In production, here we would:
        // 1. Load TensorFlow Lite model
        // 2. Prepare feature vectors (historical spending, seasonality, trends)
        // 3. Run inference
        // 4. Get predictions with confidence intervals

        Log.d(TAG, "Predicted spending for " + category + ": $" + predictedSpending +
                " (confidence: " + confidence + ")");

        return new PredictionResult(predictedSpending, confidence);
    }

    /**
     * Predict if budget will be exceeded
     */
    public BudgetWarning checkBudgetWarning(Budget budget, List<Transaction> currentMonthTransactions) {
        double currentSpent = budget.getSpent();
        double budgetLimit = budget.getAmount();

        // Calculate daily average spending
        Calendar cal = Calendar.getInstance();
        int daysInMonth = cal.getActualMaximum(Calendar.DAY_OF_MONTH);
        int currentDay = cal.get(Calendar.DAY_OF_MONTH);
        int daysRemaining = daysInMonth - currentDay;

        double dailyAverage = currentDay > 0 ? currentSpent / currentDay : 0;
        double projectedSpending = currentSpent + (dailyAverage * daysRemaining);

        boolean willExceed = projectedSpending > budgetLimit;
        double percentageUsed = (currentSpent / budgetLimit) * 100;

        String warningLevel;
        if (percentageUsed >= 100) {
            warningLevel = "EXCEEDED";
        } else if (percentageUsed >= 90) {
            warningLevel = "CRITICAL";
        } else if (percentageUsed >= 75) {
            warningLevel = "WARNING";
        } else if (percentageUsed >= 50) {
            warningLevel = "CAUTION";
        } else {
            warningLevel = "SAFE";
        }

        return new BudgetWarning(willExceed, projectedSpending, percentageUsed, warningLevel);
    }

    /**
     * Predict optimal budget for a category
     */
    public double predictOptimalBudget(String category, List<Transaction> historicalTransactions) {
        PredictionResult prediction = predictSpending(category, historicalTransactions);
        // Add 10% buffer for safety
        return prediction.getPredictedAmount() * 1.1;
    }

    /**
     * Result class for predictions
     */
    public static class PredictionResult {
        private double predictedAmount;
        private float confidence;

        public PredictionResult(double predictedAmount, float confidence) {
            this.predictedAmount = predictedAmount;
            this.confidence = confidence;
        }

        public double getPredictedAmount() {
            return predictedAmount;
        }

        public float getConfidence() {
            return confidence;
        }
    }

    /**
     * Budget warning result
     */
    public static class BudgetWarning {
        private boolean willExceed;
        private double projectedSpending;
        private double percentageUsed;
        private String warningLevel;

        public BudgetWarning(boolean willExceed, double projectedSpending,
                             double percentageUsed, String warningLevel) {
            this.willExceed = willExceed;
            this.projectedSpending = projectedSpending;
            this.percentageUsed = percentageUsed;
            this.warningLevel = warningLevel;
        }

        public boolean willExceed() {
            return willExceed;
        }

        public double getProjectedSpending() {
            return projectedSpending;
        }

        public double getPercentageUsed() {
            return percentageUsed;
        }

        public String getWarningLevel() {
            return warningLevel;
        }
    }
}