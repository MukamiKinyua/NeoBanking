package com.glorymukami.neobanking.ui.budget;

import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.github.mikephil.charting.charts.PieChart;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.data.PieData;
import com.github.mikephil.charting.data.PieDataSet;
import com.github.mikephil.charting.data.PieEntry;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.utils.ColorTemplate;
import com.glorymukami.neobanking.R;
import java.util.ArrayList;
import java.util.List;

/**
 * Budget Fragment with expenditure charts
 * Features:
 * - Pie chart showing spending by category
 * - Bar chart showing monthly trends
 * - Toast notifications on interaction
 */
public class BudgetFragment extends Fragment {

    private PieChart pieChart;
    private BarChart barChart;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_budget, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        pieChart = view.findViewById(R.id.pie_chart);
        barChart = view.findViewById(R.id.bar_chart);

        setupPieChart();
        setupBarChart();

        Toast.makeText(getContext(), "📊 Charts loaded successfully!", Toast.LENGTH_SHORT).show();
    }

    private void setupPieChart() {
        // Use real data from DummyData
        List<PieEntry> entries = new ArrayList<>();
        entries.add(new PieEntry(450f, "Food & Dining"));
        entries.add(new PieEntry(300f, "Transportation"));
        entries.add(new PieEntry(200f, "Entertainment"));
        entries.add(new PieEntry(150f, "Shopping"));
        entries.add(new PieEntry(400f, "Bills & Utilities"));
        entries.add(new PieEntry(100f, "Healthcare"));

        PieDataSet dataSet = new PieDataSet(entries, "Spending Categories");
        dataSet.setColors(ColorTemplate.MATERIAL_COLORS);
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.WHITE);

        PieData data = new PieData(dataSet);
        pieChart.setData(data);
        pieChart.getDescription().setEnabled(false);
        pieChart.setDrawHoleEnabled(true);
        pieChart.setHoleColor(Color.WHITE);
        pieChart.setTransparentCircleRadius(58f);
        pieChart.setCenterText("Total Spent\n$1,600");
        pieChart.setCenterTextSize(14f);
        pieChart.animateY(1000);
        pieChart.invalidate();

        // Click listener
        pieChart.setOnChartValueSelectedListener(new com.github.mikephil.charting.listener.OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(com.github.mikephil.charting.data.Entry e, com.github.mikephil.charting.highlight.Highlight h) {
                PieEntry entry = (PieEntry) e;
                Toast.makeText(getContext(),
                        "📊 " + entry.getLabel() + ": $" + (int)entry.getValue(),
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {
            }
        });
    }

    private void setupBarChart() {
        // Sample data - monthly spending
        List<BarEntry> entries = new ArrayList<>();
        entries.add(new BarEntry(1f, 1200f));  // Jan
        entries.add(new BarEntry(2f, 1500f));  // Feb
        entries.add(new BarEntry(3f, 1300f));  // Mar
        entries.add(new BarEntry(4f, 1600f));  // Apr
        entries.add(new BarEntry(5f, 1400f));  // May
        entries.add(new BarEntry(6f, 1600f));  // Jun

        BarDataSet dataSet = new BarDataSet(entries, "Monthly Spending ($)");
        dataSet.setColors(ColorTemplate.COLORFUL_COLORS);
        dataSet.setValueTextSize(12f);

        BarData data = new BarData(dataSet);
        barChart.setData(data);
        barChart.getDescription().setEnabled(false);
        barChart.animateY(1000);
        barChart.invalidate();

        // Click listener
        barChart.setOnChartValueSelectedListener(new com.github.mikephil.charting.listener.OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(com.github.mikephil.charting.data.Entry e, com.github.mikephil.charting.highlight.Highlight h) {
                String[] months = {"", "January", "February", "March", "April", "May", "June"};
                int month = (int) e.getX();
                Toast.makeText(getContext(),
                        "📊 " + months[month] + ": $" + e.getY(),
                        Toast.LENGTH_SHORT).show();
            }

            @Override
            public void onNothingSelected() {
            }
        });
    }
}