package com.glorymukami.neobanking.utils;

import android.content.Context;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.biometric.BiometricManager;
import androidx.biometric.BiometricPrompt;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import com.glorymukami.neobanking.R;

/**
 * Helper class for biometric authentication
 * Handles fingerprint and face recognition
 */
public class BiometricHelper {

    private static final String TAG = "BiometricHelper";
    private Context context;

    public BiometricHelper(Context context) {
        this.context = context;
    }

    /**
     * Check if biometric authentication is available
     */
    public boolean isBiometricAvailable() {
        BiometricManager biometricManager = BiometricManager.from(context);
        int result = biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
        );

        return result == BiometricManager.BIOMETRIC_SUCCESS;
    }

    /**
     * Get biometric availability status
     */
    public String getBiometricStatus() {
        BiometricManager biometricManager = BiometricManager.from(context);
        int result = biometricManager.canAuthenticate(
                BiometricManager.Authenticators.BIOMETRIC_STRONG
        );

        switch (result) {
            case BiometricManager.BIOMETRIC_SUCCESS:
                return "Biometric authentication available";
            case BiometricManager.BIOMETRIC_ERROR_NO_HARDWARE:
                return "No biometric hardware available";
            case BiometricManager.BIOMETRIC_ERROR_HW_UNAVAILABLE:
                return "Biometric hardware unavailable";
            case BiometricManager.BIOMETRIC_ERROR_NONE_ENROLLED:
                return "No biometric credentials enrolled";
            default:
                return "Unknown error";
        }
    }

    /**
     * Show biometric authentication prompt
     */
    public void showBiometricPrompt(FragmentActivity activity, BiometricAuthCallback callback) {
        BiometricPrompt.PromptInfo promptInfo = new BiometricPrompt.PromptInfo.Builder()
                .setTitle(context.getString(R.string.biometric_prompt_title))
                .setSubtitle(context.getString(R.string.biometric_prompt_subtitle))
                .setNegativeButtonText(context.getString(R.string.biometric_prompt_cancel))
                .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
                .setConfirmationRequired(true)
                .build();

        BiometricPrompt biometricPrompt = new BiometricPrompt(
                activity,
                ContextCompat.getMainExecutor(context),
                new BiometricPrompt.AuthenticationCallback() {
                    @Override
                    public void onAuthenticationSucceeded(@NonNull BiometricPrompt.AuthenticationResult result) {
                        super.onAuthenticationSucceeded(result);
                        Log.d(TAG, "Biometric authentication succeeded");
                        callback.onAuthenticationSuccess();
                    }

                    @Override
                    public void onAuthenticationError(int errorCode, @NonNull CharSequence errString) {
                        super.onAuthenticationError(errorCode, errString);
                        Log.e(TAG, "Biometric authentication error: " + errString);
                        callback.onAuthenticationError(errString.toString());
                    }

                    @Override
                    public void onAuthenticationFailed() {
                        super.onAuthenticationFailed();
                        Log.w(TAG, "Biometric authentication failed");
                        callback.onAuthenticationFailed();
                    }
                }
        );

        biometricPrompt.authenticate(promptInfo);
    }

    /**
     * Callback interface for biometric authentication
     */
    public interface BiometricAuthCallback {
        void onAuthenticationSuccess();
        void onAuthenticationError(String error);
        void onAuthenticationFailed();
    }
}