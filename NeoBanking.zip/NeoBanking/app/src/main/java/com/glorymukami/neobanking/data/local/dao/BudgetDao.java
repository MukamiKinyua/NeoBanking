package com.glorymukami.neobanking.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.glorymukami.neobanking.data.local.entities.Budget;
import java.util.Date;
import java.util.List;

/**
 * Data Access Object for Budget entity
 */
@Dao
public interface BudgetDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Budget budget);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Budget> budgets);

    @Update
    void update(Budget budget);

    @Delete
    void delete(Budget budget);

    @Query("SELECT * FROM budgets WHERE is_active = 1 ORDER BY category ASC")
    LiveData<List<Budget>> getAllActiveBudgets();

    @Query("SELECT * FROM budgets WHERE id = :budgetId")
    LiveData<Budget> getBudgetById(long budgetId);

    @Query("SELECT * FROM budgets WHERE category = :category AND is_active = 1 LIMIT 1")
    LiveData<Budget> getBudgetByCategory(String category);

    @Query("SELECT * FROM budgets WHERE is_active = 1 AND end_date >= :currentDate")
    LiveData<List<Budget>> getCurrentBudgets(Date currentDate);

    @Query("SELECT * FROM budgets WHERE spent > amount AND is_active = 1")
    LiveData<List<Budget>> getOverBudgets();

    @Query("UPDATE budgets SET spent = :spent, updated_at = :updatedAt WHERE id = :budgetId")
    void updateSpent(long budgetId, double spent, Date updatedAt);

    @Query("UPDATE budgets SET predicted_spending = :predictedSpending, prediction_confidence = :confidence WHERE id = :budgetId")
    void updatePrediction(long budgetId, double predictedSpending, float confidence);

    @Query("DELETE FROM budgets WHERE end_date < :date AND is_active = 0")
    void deleteOldBudgets(Date date);

    @Query("SELECT SUM(amount) FROM budgets WHERE is_active = 1")
    LiveData<Double> getTotalBudgetAmount();

    @Query("SELECT SUM(spent) FROM budgets WHERE is_active = 1")
    LiveData<Double> getTotalSpent();

    @Query("SELECT COUNT(*) FROM budgets WHERE is_active = 1")
    LiveData<Integer> getActiveBudgetCount();
}