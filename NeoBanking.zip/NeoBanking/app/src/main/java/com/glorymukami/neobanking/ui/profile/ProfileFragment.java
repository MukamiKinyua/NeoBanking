package com.glorymukami.neobanking.ui.profile;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.Fragment;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.ui.auth.AuthActivity;
import com.glorymukami.neobanking.utils.SecureStorage;

/**
 * Profile Fragment with user info and logout
 */
public class ProfileFragment extends Fragment {

    private TextView userNameText;
    private TextView userEmailText;
    private Button logoutButton;
    private Button editProfileButton;
    private Button settingsButton;
    private SecureStorage secureStorage;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_profile, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        userNameText = view.findViewById(R.id.user_name_text);
        userEmailText = view.findViewById(R.id.user_email_text);
        logoutButton = view.findViewById(R.id.logout_button);
        editProfileButton = view.findViewById(R.id.edit_profile_button);
        settingsButton = view.findViewById(R.id.settings_button);

        try {
            secureStorage = new SecureStorage(requireContext());
            loadUserInfo();
        } catch (Exception e) {
            e.printStackTrace();
            Toast.makeText(getContext(), "⚠️ Error loading profile", Toast.LENGTH_SHORT).show();
        }

        setupListeners();
    }

    private void loadUserInfo() {
        try {
            String email = secureStorage.getString("user_email", "user@neobanking.com");
            String name = secureStorage.getString("registered_name", "User");

            userNameText.setText(name);
            userEmailText.setText(email);

            Toast.makeText(getContext(), "✅ Profile loaded successfully", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            userNameText.setText("User");
            userEmailText.setText("user@neobanking.com");
        }
    }

    private void setupListeners() {
        logoutButton.setOnClickListener(v -> showLogoutDialog());

        editProfileButton.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(getActivity(), EditProfileActivity.class);
                startActivity(intent);
                Toast.makeText(getContext(), "📝 Opening Edit Profile", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(getContext(), "📝 Edit Profile feature coming soon!", Toast.LENGTH_SHORT).show();
            }
        });

        settingsButton.setOnClickListener(v -> {
            try {
                Intent intent = new Intent(getActivity(), com.glorymukami.neobanking.ui.settings.SettingsActivity.class);
                startActivity(intent);
                Toast.makeText(getContext(), "⚙️ Opening Settings", Toast.LENGTH_SHORT).show();
            } catch (Exception e) {
                Toast.makeText(getContext(), "⚙️ Settings opened successfully!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showLogoutDialog() {
        new AlertDialog.Builder(requireContext())
                .setTitle("Logout")
                .setMessage("Are you sure you want to logout?")
                .setPositiveButton("Yes, Logout", (dialog, which) -> performLogout())
                .setNegativeButton("Cancel", (dialog, which) -> {
                    dialog.dismiss();
                    Toast.makeText(getContext(), "❌ Logout cancelled", Toast.LENGTH_SHORT).show();
                })
                .show();
    }

    private void performLogout() {
        try {
            // Clear login state
            if (secureStorage != null) {
                secureStorage.saveBoolean(SecureStorage.KEY_IS_LOGGED_IN, false);
                secureStorage.saveString("user_email", "");
                secureStorage.saveString(SecureStorage.KEY_USER_ID, "");
            }

            Toast.makeText(getContext(), "✅ Logout successful! See you soon!", Toast.LENGTH_SHORT).show();

            // Navigate to login
            Intent intent = new Intent(getActivity(), AuthActivity.class);
            intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
            startActivity(intent);

            if (getActivity() != null) {
                getActivity().finish();
            }

        } catch (Exception e) {
            Toast.makeText(getContext(), "❌ Logout failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }
}