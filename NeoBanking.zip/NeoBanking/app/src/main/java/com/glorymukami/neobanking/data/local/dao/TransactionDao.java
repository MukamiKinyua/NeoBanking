package com.glorymukami.neobanking.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.glorymukami.neobanking.data.local.entities.Transaction;
import java.util.Date;
import java.util.List;

/**
 * Data Access Object for Transaction entity
 * Provides methods to interact with transaction data
 */
@Dao
public interface TransactionDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Transaction transaction);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Transaction> transactions);

    @Update
    void update(Transaction transaction);

    @Delete
    void delete(Transaction transaction);

    @Query("SELECT * FROM transactions ORDER BY date DESC")
    LiveData<List<Transaction>> getAllTransactions();

    @Query("SELECT * FROM transactions WHERE id = :transactionId")
    LiveData<Transaction> getTransactionById(long transactionId);

    @Query("SELECT * FROM transactions WHERE account_id = :accountId ORDER BY date DESC")
    LiveData<List<Transaction>> getTransactionsByAccount(String accountId);

    @Query("SELECT * FROM transactions WHERE category = :category ORDER BY date DESC")
    LiveData<List<Transaction>> getTransactionsByCategory(String category);

    @Query("SELECT * FROM transactions WHERE date BETWEEN :startDate AND :endDate ORDER BY date DESC")
    LiveData<List<Transaction>> getTransactionsBetweenDates(Date startDate, Date endDate);

    @Query("SELECT * FROM transactions WHERE synced = 0")
    List<Transaction> getUnsyncedTransactions();

    @Query("SELECT * FROM transactions WHERE category = :category AND date BETWEEN :startDate AND :endDate")
    LiveData<List<Transaction>> getTransactionsByCategoryAndDateRange(String category, Date startDate, Date endDate);

    @Query("SELECT SUM(amount) FROM transactions WHERE type = 'DEBIT' AND date BETWEEN :startDate AND :endDate")
    LiveData<Double> getTotalExpenses(Date startDate, Date endDate);

    @Query("SELECT SUM(amount) FROM transactions WHERE type = 'CREDIT' AND date BETWEEN :startDate AND :endDate")
    LiveData<Double> getTotalIncome(Date startDate, Date endDate);

    @Query("SELECT SUM(amount) FROM transactions WHERE category = :category AND date BETWEEN :startDate AND :endDate")
    LiveData<Double> getSpendingByCategory(String category, Date startDate, Date endDate);

    @Query("DELETE FROM transactions WHERE date < :date")
    void deleteOldTransactions(Date date);

    @Query("SELECT * FROM transactions WHERE description LIKE '%' || :searchQuery || '%' OR merchant_name LIKE '%' || :searchQuery || '%' ORDER BY date DESC")
    LiveData<List<Transaction>> searchTransactions(String searchQuery);

    @Query("SELECT COUNT(*) FROM transactions")
    LiveData<Integer> getTransactionCount();
}