package com.glorymukami.neobanking.ui.onboarding;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.*;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.glorymukami.neobanking.R;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;

public class OnboardingPageFragment extends Fragment {

    private static final String ARG_PAGE_NUMBER = "page_number";
    private static final int PICK_IMAGE = 100;

    private int pageNumber;
    private View rootView;

    public static OnboardingPageFragment newInstance(int pageNumber) {
        OnboardingPageFragment fragment = new OnboardingPageFragment();
        Bundle args = new Bundle();
        args.putInt(ARG_PAGE_NUMBER, pageNumber);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            pageNumber = getArguments().getInt(ARG_PAGE_NUMBER);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        rootView = inflater.inflate(getLayoutForPage(pageNumber), container, false);
        setupPage(pageNumber);
        return rootView;
    }

    private int getLayoutForPage(int page) {
        switch (page) {
            case 1: return R.layout.fragment_onboarding_personal;
            case 2: return R.layout.fragment_onboarding_contact;
            case 3: return R.layout.fragment_onboarding_financial;
            case 4: return R.layout.fragment_onboarding_documents;
            case 5: return R.layout.fragment_onboarding_employment;
            case 6: return R.layout.fragment_onboarding_preferences;
            case 7: return R.layout.fragment_onboarding_security;
            case 8: return R.layout.fragment_onboarding_signature;
            default: return R.layout.fragment_onboarding_personal;
        }
    }

    private void setupPage(int page) {
        switch (page) {
            case 4:
                setupDocumentUploads();
                break;
            case 8:
                setupSignature();
                break;
        }
    }

    private void setupDocumentUploads() {
        // ID Upload
        MaterialButton uploadIdButton = rootView.findViewById(R.id.upload_id_button);
        if (uploadIdButton != null) {
            uploadIdButton.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE);
                Toast.makeText(getContext(), "📷 Select ID document photo", Toast.LENGTH_SHORT).show();
            });
        }

        // Address Proof Upload
        MaterialButton uploadAddressButton = rootView.findViewById(R.id.upload_address_button);
        if (uploadAddressButton != null) {
            uploadAddressButton.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE);
                Toast.makeText(getContext(), "📷 Select address proof photo", Toast.LENGTH_SHORT).show();
            });
        }

        // Income Proof Upload
        MaterialButton uploadIncomeButton = rootView.findViewById(R.id.upload_income_button);
        if (uploadIncomeButton != null) {
            uploadIncomeButton.setOnClickListener(v -> {
                Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
                startActivityForResult(intent, PICK_IMAGE);
                Toast.makeText(getContext(), "📷 Select income proof photo", Toast.LENGTH_SHORT).show();
            });
        }

        // Selfie Capture
        MaterialButton captureSelfieButton = rootView.findViewById(R.id.capture_selfie_button);
        if (captureSelfieButton != null) {
            captureSelfieButton.setOnClickListener(v -> {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, PICK_IMAGE);
                Toast.makeText(getContext(), "📸 Capture your selfie", Toast.LENGTH_SHORT).show();
            });
        }
    }

    private void setupSignature() {
        MaterialButton clearSignatureButton = rootView.findViewById(R.id.clear_signature_button);
        if (clearSignatureButton != null) {
            clearSignatureButton.setOnClickListener(v -> {
                // Clear signature pad
                Toast.makeText(getContext(), "🗑️ Signature cleared", Toast.LENGTH_SHORT).show();
            });
        }
    }

    public boolean validatePage() {
        switch (pageNumber) {
            case 1:
                return validatePersonalInfo();
            case 2:
                return validateContactInfo();
            case 3:
                return validateFinancialInfo();
            case 4:
                return validateDocuments();
            case 5:
                return validateEmployment();
            case 6:
                return validatePreferences();
            case 7:
                return validateSecurity();
            case 8:
                return validateSignature();
            default:
                return true;
        }
    }

    private boolean validatePersonalInfo() {
        TextInputEditText fullName = rootView.findViewById(R.id.full_name_input);
        if (fullName != null && fullName.getText().toString().trim().isEmpty()) {
            fullName.setError("Full name is required");
            Toast.makeText(getContext(), "❌ Please enter your full name", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean validateContactInfo() {
        TextInputEditText email = rootView.findViewById(R.id.email_input);
        if (email != null && email.getText().toString().trim().isEmpty()) {
            email.setError("Email is required");
            Toast.makeText(getContext(), "❌ Please enter your email", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean validateFinancialInfo() {
        Spinner employmentStatus = rootView.findViewById(R.id.employment_status_spinner);
        if (employmentStatus != null && employmentStatus.getSelectedItemPosition() == 0) {
            Toast.makeText(getContext(), "❌ Please select employment status", Toast.LENGTH_SHORT).show();
            return false;
        }
        return true;
    }

    private boolean validateDocuments() {
        Toast.makeText(getContext(), "⚠️ Please upload at least one ID document", Toast.LENGTH_SHORT).show();
        return true; // Allow skipping for demo
    }

    private boolean validateEmployment() {
        return true;
    }

    private boolean validatePreferences() {
        return true;
    }

    private boolean validateSecurity() {
        return true;
    }

    private boolean validateSignature() {
        Toast.makeText(getContext(), "⚠️ Please provide your digital signature", Toast.LENGTH_SHORT).show();
        return true; // Allow skipping for demo
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode == Activity.RESULT_OK && data != null) {
            Toast.makeText(getContext(), "✅ File uploaded successfully", Toast.LENGTH_SHORT).show();
        }
    }
}