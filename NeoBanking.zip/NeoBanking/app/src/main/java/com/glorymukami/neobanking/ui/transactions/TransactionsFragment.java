package com.glorymukami.neobanking.ui.transactions;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.models.Transaction;
import com.glorymukami.neobanking.utils.DummyData;
import java.util.List;

public class TransactionsFragment extends Fragment {

    private RecyclerView recyclerView;
    private TransactionsAdapter adapter;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_transactions, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = view.findViewById(R.id.transactions_recycler);
        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));

        // Load dummy transaction data
        List<Transaction> transactions = DummyData.getTransactions();
        adapter = new TransactionsAdapter(transactions);
        recyclerView.setAdapter(adapter);

        Toast.makeText(getContext(), "✅ Loaded " + transactions.size() + " transactions", Toast.LENGTH_SHORT).show();
    }
}