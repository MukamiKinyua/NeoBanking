package com.glorymukami.neobanking.utils;

import android.app.Activity;
import android.content.Context;
import android.util.Log;
import android.widget.Toast;
import org.json.JSONException;
import org.json.JSONObject;

/**
 * Helper class for Plaid Link integration
 *
 * NOTE: This is a PLACEHOLDER implementation.
 * Plaid SDK has been disabled to avoid compilation errors.
 *
 * To enable Plaid:
 * 1. Sign up at https://plaid.com and get API credentials
 * 2. Uncomment Plaid SDK in build.gradle:
 *    implementation 'com.plaid.link:sdk-core:4.1.0'
 * 3. Implement the actual Plaid Link flow
 * 4. Replace the placeholder methods below
 *
 * For now, this class provides stub methods that won't cause errors.
 */
public class PlaidHelper {

    private static final String TAG = "PlaidHelper";
    private Context context;

    public PlaidHelper(Context context) {
        this.context = context;
    }

    /**
     * Initialize Plaid Link with link token
     * PLACEHOLDER: Plaid SDK is not configured
     */
    public void initializePlaid(Activity activity, String linkToken, PlaidLinkCallback callback) {
        Log.d(TAG, "Plaid SDK not configured. This is a placeholder.");

        // Show message to user
        Toast.makeText(activity,
                "Plaid integration requires setup. Check PlaidHelper.java for instructions.",
                Toast.LENGTH_LONG).show();

        // Call error callback
        if (callback != null) {
            callback.onError("Plaid SDK not configured. Add your credentials to enable.");
        }
    }

    /**
     * Open Plaid Link UI
     * PLACEHOLDER: Plaid SDK is not configured
     */
    public void openPlaidLink(Activity activity, PlaidLinkCallback callback) {
        Log.d(TAG, "Plaid Link unavailable. SDK not configured.");

        Toast.makeText(activity,
                "Bank account linking requires Plaid setup",
                Toast.LENGTH_SHORT).show();

        if (callback != null) {
            callback.onError("Plaid SDK not configured");
        }
    }

    /**
     * Create link token request JSON
     * This JSON should be sent to your backend server to get a link token
     */
    public JSONObject createLinkTokenRequest(String userId) {
        try {
            JSONObject request = new JSONObject();
            request.put("user_id", userId);
            request.put("client_name", "NeoBanking");
            request.put("country_codes", new String[]{"US"});
            request.put("language", "en");

            JSONObject user = new JSONObject();
            user.put("client_user_id", userId);
            request.put("user", user);

            return request;
        } catch (JSONException e) {
            Log.e(TAG, "Error creating link token request", e);
            return null;
        }
    }

    /**
     * Create token exchange request JSON
     * This JSON should be sent to your backend to exchange public token for access token
     */
    public JSONObject createTokenExchangeRequest(String publicToken) {
        try {
            JSONObject request = new JSONObject();
            request.put("public_token", publicToken);
            return request;
        } catch (JSONException e) {
            Log.e(TAG, "Error creating token exchange request", e);
            return null;
        }
    }

    /**
     * Callback interface for Plaid Link events
     * Simple interface that doesn't depend on Plaid SDK classes
     */
    public interface PlaidLinkCallback {
        /**
         * Called when Plaid Link succeeds
         * @param publicToken The public token to exchange for an access token
         * @param metadata Additional metadata (as JSON string)
         */
        void onSuccess(String publicToken, String metadata);

        /**
         * Called when an error occurs
         * @param error Error message
         */
        void onError(String error);

        /**
         * Called when user exits Plaid Link
         */
        void onExit();
    }

    /**
     * Update mode - for re-authenticating existing connections
     * PLACEHOLDER: Requires Plaid SDK
     */
    public void updateAccount(Activity activity, String linkToken, PlaidLinkCallback callback) {
        Log.d(TAG, "Update account - Plaid SDK not configured");
        initializePlaid(activity, linkToken, callback);
    }

    /**
     * Check if Plaid is properly configured
     * @return false (always, since SDK is not included)
     */
    public boolean isPlaidConfigured() {
        return false;
    }

    /**
     * Get configuration instructions
     * @return Instructions for setting up Plaid
     */
    public String getSetupInstructions() {
        return "To enable Plaid:\n" +
                "1. Get API credentials from https://plaid.com\n" +
                "2. Uncomment Plaid SDK in build.gradle\n" +
                "3. Implement Plaid Link flow in PlaidHelper.java\n" +
                "4. Configure link token endpoint on your backend";
    }
}