package com.glorymukami.neobanking.ui.transactions;

import android.graphics.Color;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.models.Transaction;
import java.util.List;

public class TransactionsAdapter extends RecyclerView.Adapter<TransactionsAdapter.ViewHolder> {

    private List<Transaction> transactions;

    public TransactionsAdapter(List<Transaction> transactions) {
        this.transactions = transactions;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_transaction, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        Transaction transaction = transactions.get(position);

        holder.titleText.setText(transaction.getTitle());
        holder.categoryText.setText(transaction.getCategory());
        holder.dateText.setText(transaction.getDate());

        String amountText = transaction.isIncome() ?
                "+$" + String.format("%.2f", transaction.getAmount()) :
                "-$" + String.format("%.2f", transaction.getAmount());
        holder.amountText.setText(amountText);

        int color = transaction.isIncome() ? Color.parseColor("#4CAF50") : Color.parseColor("#F44336");
        holder.amountText.setTextColor(color);
    }

    @Override
    public int getItemCount() {
        return transactions.size();
    }

    static class ViewHolder extends RecyclerView.ViewHolder {
        TextView titleText;
        TextView categoryText;
        TextView dateText;
        TextView amountText;

        ViewHolder(@NonNull View itemView) {
            super(itemView);
            titleText = itemView.findViewById(R.id.transaction_title);
            categoryText = itemView.findViewById(R.id.transaction_category);
            dateText = itemView.findViewById(R.id.transaction_date);
            amountText = itemView.findViewById(R.id.transaction_amount);
        }
    }
}