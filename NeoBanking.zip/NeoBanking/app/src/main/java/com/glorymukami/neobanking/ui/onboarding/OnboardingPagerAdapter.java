package com.glorymukami.neobanking.ui.onboarding;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import java.util.ArrayList;
import java.util.List;

public class OnboardingPagerAdapter extends FragmentStateAdapter {

    private final List<OnboardingPageFragment> fragments = new ArrayList<>();
    private final List<String> pageTitles = new ArrayList<>();

    public OnboardingPagerAdapter(@NonNull FragmentActivity fragmentActivity) {
        super(fragmentActivity);
        setupPages();
    }

    private void setupPages() {
        // Page 1: Personal Information
        fragments.add(OnboardingPageFragment.newInstance(1));
        pageTitles.add("Personal Info");

        // Page 2: Contact & Address
        fragments.add(OnboardingPageFragment.newInstance(2));
        pageTitles.add("Contact");

        // Page 3: Financial Information
        fragments.add(OnboardingPageFragment.newInstance(3));
        pageTitles.add("Financial");

        // Page 4: Document Upload
        fragments.add(OnboardingPageFragment.newInstance(4));
        pageTitles.add("Documents");

        // Page 5: Employment Details
        fragments.add(OnboardingPageFragment.newInstance(5));
        pageTitles.add("Employment");

        // Page 6: Account Preferences
        fragments.add(OnboardingPageFragment.newInstance(6));
        pageTitles.add("Preferences");

        // Page 7: Security & Compliance
        fragments.add(OnboardingPageFragment.newInstance(7));
        pageTitles.add("Security");

        // Page 8: Signature & Verification
        fragments.add(OnboardingPageFragment.newInstance(8));
        pageTitles.add("Signature");
    }

    @NonNull
    @Override
    public Fragment createFragment(int position) {
        return fragments.get(position);
    }

    @Override
    public int getItemCount() {
        return fragments.size();
    }

    public String getPageTitle(int position) {
        return pageTitles.get(position);
    }

    public OnboardingPageFragment getFragment(int position) {
        if (position >= 0 && position < fragments.size()) {
            return fragments.get(position);
        }
        return null;
    }
}