package com.glorymukami.neobanking.data.local.dao;

import androidx.lifecycle.LiveData;
import androidx.room.*;
import com.glorymukami.neobanking.data.local.entities.Account;
import java.util.List;

/**
 * Data Access Object for Account entity
 */
@Dao
public interface AccountDao {

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    long insert(Account account);

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    void insertAll(List<Account> accounts);

    @Update
    void update(Account account);

    @Delete
    void delete(Account account);

    @Query("SELECT * FROM accounts WHERE is_active = 1 ORDER BY created_at DESC")
    LiveData<List<Account>> getAllActiveAccounts();

    @Query("SELECT * FROM accounts ORDER BY created_at DESC")
    LiveData<List<Account>> getAllAccounts();

    @Query("SELECT * FROM accounts WHERE id = :accountId")
    LiveData<Account> getAccountById(long accountId);

    @Query("SELECT * FROM accounts WHERE plaid_account_id = :plaidAccountId")
    LiveData<Account> getAccountByPlaidId(String plaidAccountId);

    @Query("SELECT SUM(current_balance) FROM accounts WHERE is_active = 1")
    LiveData<Double> getTotalBalance();

    @Query("SELECT SUM(available_balance) FROM accounts WHERE is_active = 1")
    LiveData<Double> getTotalAvailableBalance();

    @Query("SELECT * FROM accounts WHERE account_type = :accountType AND is_active = 1")
    LiveData<List<Account>> getAccountsByType(String accountType);

    @Query("UPDATE accounts SET is_active = 0 WHERE id = :accountId")
    void deactivateAccount(long accountId);

    @Query("DELETE FROM accounts")
    void deleteAll();

    @Query("SELECT COUNT(*) FROM accounts WHERE is_active = 1")
    LiveData<Integer> getActiveAccountCount();
}