package com.glorymukami.neobanking.ui.chatbot;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.glorymukami.neobanking.R;
import java.util.ArrayList;
import java.util.List;

/**
 * AI Chatbot Fragment for financial advice
 * Features:
 * - Financial advice
 * - Budget recommendations
 * - Spending insights
 * - AI-powered responses
 */
public class ChatbotFragment extends Fragment {

    private RecyclerView chatRecyclerView;
    private EditText messageInput;
    private ImageButton sendButton;
    private ChatAdapter chatAdapter;
    private List<ChatMessage> messages;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_chatbot, container, false);
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        chatRecyclerView = view.findViewById(R.id.chat_recycler_view);
        messageInput = view.findViewById(R.id.message_input);
        sendButton = view.findViewById(R.id.send_button);

        messages = new ArrayList<>();
        chatAdapter = new ChatAdapter(messages);

        chatRecyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        chatRecyclerView.setAdapter(chatAdapter);

        // Add welcome message
        addBotMessage("👋 Hello! I'm your AI Financial Advisor. How can I help you manage your finances today?");

        sendButton.setOnClickListener(v -> sendMessage());
    }

    private void sendMessage() {
        String message = messageInput.getText().toString().trim();

        if (message.isEmpty()) {
            Toast.makeText(getContext(), "⚠️ Please enter a message", Toast.LENGTH_SHORT).show();
            return;
        }

        // Add user message
        addUserMessage(message);
        messageInput.setText("");

        // Show typing indicator
        Toast.makeText(getContext(), "🤖 AI is thinking...", Toast.LENGTH_SHORT).show();

        // Generate AI response
        String response = generateAIResponse(message);
        addBotMessage(response);

        // Scroll to bottom
        chatRecyclerView.smoothScrollToPosition(messages.size() - 1);
    }

    private String generateAIResponse(String userMessage) {
        String msg = userMessage.toLowerCase();

        // Budget advice
        if (msg.contains("budget") || msg.contains("save")) {
            return "💰 Budget Tip: Follow the 50/30/20 rule:\n" +
                    "• 50% for needs (rent, food, bills)\n" +
                    "• 30% for wants (entertainment)\n" +
                    "• 20% for savings & debt\n\n" +
                    "Would you like me to analyze your spending?";
        }

        // Spending advice
        if (msg.contains("spend") || msg.contains("expense")) {
            return "📊 Spending Insight: Your top categories this month:\n" +
                    "• Food & Dining: $450\n" +
                    "• Transportation: $200\n" +
                    "• Entertainment: $150\n\n" +
                    "You're spending 15% more on dining out than last month. Consider meal prep to save!";
        }

        // Savings advice
        if (msg.contains("saving") || msg.contains("invest")) {
            return "💵 Savings Strategy:\n" +
                    "1. Build emergency fund (3-6 months expenses)\n" +
                    "2. Pay off high-interest debt\n" +
                    "3. Invest in index funds or retirement accounts\n\n" +
                    "Start with saving just $50/week. That's $2,600/year!";
        }

        // Debt management
        if (msg.contains("debt") || msg.contains("loan") || msg.contains("credit")) {
            return "💳 Debt Management:\n" +
                    "• Pay off highest interest rate first\n" +
                    "• Make more than minimum payments\n" +
                    "• Consider debt consolidation\n\n" +
                    "Would you like help creating a debt payoff plan?";
        }

        // Income advice
        if (msg.contains("income") || msg.contains("earn") || msg.contains("money")) {
            return "💼 Income Tips:\n" +
                    "• Negotiate salary increase\n" +
                    "• Start side hustle\n" +
                    "• Invest in skill development\n" +
                    "• Passive income streams\n\n" +
                    "What skills do you have that could generate extra income?";
        }

        // Emergency fund
        if (msg.contains("emergency")) {
            return "🚨 Emergency Fund:\n" +
                    "Aim for 3-6 months of expenses. Based on your average monthly spending of $2,500:\n" +
                    "• Minimum: $7,500\n" +
                    "• Recommended: $15,000\n\n" +
                    "Start small: $100/month = $1,200/year!";
        }

        // Default response
        return "🤖 I can help you with:\n" +
                "• Budget planning\n" +
                "• Spending analysis\n" +
                "• Savings strategies\n" +
                "• Debt management\n" +
                "• Income growth\n" +
                "• Emergency funds\n\n" +
                "What would you like to know about?";
    }

    private void addUserMessage(String text) {
        messages.add(new ChatMessage(text, true));
        chatAdapter.notifyItemInserted(messages.size() - 1);
    }

    private void addBotMessage(String text) {
        messages.add(new ChatMessage(text, false));
        chatAdapter.notifyItemInserted(messages.size() - 1);
    }
}