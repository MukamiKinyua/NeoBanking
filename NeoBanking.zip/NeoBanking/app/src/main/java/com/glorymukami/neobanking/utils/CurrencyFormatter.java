package com.glorymukami.neobanking.utils;

import java.text.NumberFormat;
import java.util.Currency;
import java.util.Locale;

/**
 * Utility class for currency formatting
 */
public class CurrencyFormatter {

    /**
     * Format amount as currency string
     */
    public static String format(double amount) {
        return format(amount, "USD");
    }

    /**
     * Format amount with specific currency
     */
    public static String format(double amount, String currencyCode) {
        try {
            NumberFormat formatter = NumberFormat.getCurrencyInstance(Locale.US);
            formatter.setCurrency(Currency.getInstance(currencyCode));
            return formatter.format(amount);
        } catch (Exception e) {
            return String.format("$%.2f", amount);
        }
    }

    /**
     * Format amount without currency symbol
     */
    public static String formatWithoutSymbol(double amount) {
        return String.format("%.2f", amount);
    }

    /**
     * Format amount with sign (+ or -)
     */
    public static String formatWithSign(double amount) {
        String formatted = format(Math.abs(amount));
        return amount >= 0 ? "+" + formatted : "-" + formatted;
    }

    /**
     * Parse currency string to double
     */
    public static double parse(String currencyString) {
        try {
            String cleaned = currencyString.replaceAll("[^0-9.-]", "");
            return Double.parseDouble(cleaned);
        } catch (Exception e) {
            return 0.0;
        }
    }

    /**
     * Format as compact currency (e.g., $1.2K, $3.5M)
     */
    public static String formatCompact(double amount) {
        if (Math.abs(amount) < 1000) {
            return format(amount);
        } else if (Math.abs(amount) < 1000000) {
            return String.format("$%.1fK", amount / 1000);
        } else if (Math.abs(amount) < 1000000000) {
            return String.format("$%.1fM", amount / 1000000);
        } else {
            return String.format("$%.1fB", amount / 1000000000);
        }
    }
}