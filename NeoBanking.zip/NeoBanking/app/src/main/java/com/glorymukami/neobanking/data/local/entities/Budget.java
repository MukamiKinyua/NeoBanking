package com.glorymukami.neobanking.data.local.entities;

import androidx.room.Entity;
import androidx.room.PrimaryKey;
import androidx.room.ColumnInfo;
import androidx.room.TypeConverters;
import com.glorymukami.neobanking.data.local.Converters;
import java.util.Date;

/**
 * Budget entity for Room database
 * Stores budget information with ML predictions
 */
@Entity(tableName = "budgets")
@TypeConverters(Converters.class)
public class Budget {

    @PrimaryKey(autoGenerate = true)
    private long id;

    @ColumnInfo(name = "category")
    private String category;

    @ColumnInfo(name = "amount")
    private double amount; // Budget limit

    @ColumnInfo(name = "spent")
    private double spent; // Amount spent so far

    @ColumnInfo(name = "currency")
    private String currency;

    @ColumnInfo(name = "period") // MONTHLY, WEEKLY, YEARLY
    private String period;

    @ColumnInfo(name = "start_date")
    private Date startDate;

    @ColumnInfo(name = "end_date")
    private Date endDate;

    @ColumnInfo(name = "predicted_spending") // ML prediction
    private double predictedSpending;

    @ColumnInfo(name = "prediction_confidence")
    private float predictionConfidence;

    @ColumnInfo(name = "is_active")
    private boolean isActive;

    @ColumnInfo(name = "created_at")
    private Date createdAt;

    @ColumnInfo(name = "updated_at")
    private Date updatedAt;

    // Constructor
    public Budget() {
        this.createdAt = new Date();
        this.updatedAt = new Date();
        this.isActive = true;
        this.currency = "USD";
        this.spent = 0.0;
    }

    // Helper method
    public double getRemainingAmount() {
        return amount - spent;
    }

    public double getSpentPercentage() {
        if (amount == 0) return 0;
        return (spent / amount) * 100;
    }

    public boolean isOverBudget() {
        return spent > amount;
    }

    // Getters and Setters
    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public double getAmount() {
        return amount;
    }

    public void setAmount(double amount) {
        this.amount = amount;
    }

    public double getSpent() {
        return spent;
    }

    public void setSpent(double spent) {
        this.spent = spent;
    }

    public String getCurrency() {
        return currency;
    }

    public void setCurrency(String currency) {
        this.currency = currency;
    }

    public String getPeriod() {
        return period;
    }

    public void setPeriod(String period) {
        this.period = period;
    }

    public Date getStartDate() {
        return startDate;
    }

    public void setStartDate(Date startDate) {
        this.startDate = startDate;
    }

    public Date getEndDate() {
        return endDate;
    }

    public void setEndDate(Date endDate) {
        this.endDate = endDate;
    }

    public double getPredictedSpending() {
        return predictedSpending;
    }

    public void setPredictedSpending(double predictedSpending) {
        this.predictedSpending = predictedSpending;
    }

    public float getPredictionConfidence() {
        return predictionConfidence;
    }

    public void setPredictionConfidence(float predictionConfidence) {
        this.predictionConfidence = predictionConfidence;
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        isActive = active;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    public Date getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(Date updatedAt) {
        this.updatedAt = updatedAt;
    }
}