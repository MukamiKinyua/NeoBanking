package com.glorymukami.neobanking.ui.auth;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.ui.main.MainActivity;
import com.glorymukami.neobanking.utils.SecureStorage;

/**
 * Clean authentication activity with login and registration
 */
public class AuthActivity extends AppCompatActivity {

    private static final String TAG = "AuthActivity";
    private static final String VALID_EMAIL = "admin@neobanking.com";
    private static final String VALID_PASSWORD = "password123";

    private EditText emailInput;
    private EditText passwordInput;
    private EditText confirmPasswordInput;
    private EditText fullNameInput;
    private EditText phoneInput;
    private Button loginButton;
    private Button registerButton;
    private TextView switchModeButton;
    private ProgressBar progressBar;
    private TextView modeTitle;

    // Parent layouts for visibility control
    private View confirmPasswordLayout;
    private View fullNameLayout;
    private View phoneLayout;

    private boolean isLoginMode = true;
    private SecureStorage secureStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_auth);

        try {
            initViews();
            initSecureStorage();
            setupListeners();
            Log.d(TAG, "✅ AuthActivity initialized successfully");
        } catch (Exception e) {
            Log.e(TAG, "❌ Error initializing", e);
            Toast.makeText(this, "❌ Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void initViews() {
        emailInput = findViewById(R.id.email_input);
        passwordInput = findViewById(R.id.password_input);
        loginButton = findViewById(R.id.login_button);
        progressBar = findViewById(R.id.progress_bar);

        confirmPasswordInput = findViewById(R.id.confirm_password_input);
        fullNameInput = findViewById(R.id.full_name_input);
        phoneInput = findViewById(R.id.phone_input);
        registerButton = findViewById(R.id.register_button);
        switchModeButton = findViewById(R.id.switch_mode_button);
        modeTitle = findViewById(R.id.mode_title);

        // Get parent layouts for visibility control
        confirmPasswordLayout = findViewById(R.id.confirm_password_input_layout);
        fullNameLayout = findViewById(R.id.full_name_input_layout);
        phoneLayout = findViewById(R.id.phone_input_layout);

        setLoginMode(true);
    }

    private void initSecureStorage() {
        try {
            secureStorage = new SecureStorage(this);
        } catch (Exception e) {
            Log.e(TAG, "SecureStorage init failed", e);
            secureStorage = null;
        }
    }

    private void setupListeners() {
        loginButton.setOnClickListener(v -> handleLogin());
        registerButton.setOnClickListener(v -> handleRegistration());
        switchModeButton.setOnClickListener(v -> {
            setLoginMode(!isLoginMode);
            Toast.makeText(this, isLoginMode ? "📝 Switched to Login" : "📝 Switched to Registration", Toast.LENGTH_SHORT).show();
        });
    }

    private void setLoginMode(boolean loginMode) {
        isLoginMode = loginMode;

        if (isLoginMode) {
            modeTitle.setText("Login to NeoBanking");
            loginButton.setVisibility(View.VISIBLE);
            registerButton.setVisibility(View.GONE);
            confirmPasswordLayout.setVisibility(View.GONE);
            fullNameLayout.setVisibility(View.GONE);
            phoneLayout.setVisibility(View.GONE);
            switchModeButton.setText("Don't have an account? Register");
        } else {
            modeTitle.setText("Create Account");
            loginButton.setVisibility(View.GONE);
            registerButton.setVisibility(View.VISIBLE);
            confirmPasswordLayout.setVisibility(View.VISIBLE);
            fullNameLayout.setVisibility(View.VISIBLE);
            phoneLayout.setVisibility(View.VISIBLE);
            switchModeButton.setText("Already have an account? Login");
        }
    }

    private void handleLogin() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (email.isEmpty()) {
            emailInput.setError("Email is required");
            Toast.makeText(this, "❌ Please enter your email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isValidEmail(email)) {
            emailInput.setError("Invalid email format");
            Toast.makeText(this, "❌ Invalid email format", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.isEmpty()) {
            passwordInput.setError("Password is required");
            Toast.makeText(this, "❌ Please enter your password", Toast.LENGTH_SHORT).show();
            return;
        }

        // Check if it's the demo admin account
        if (email.equals(VALID_EMAIL) && password.equals(VALID_PASSWORD)) {
            Toast.makeText(this, "✅ Login Successful! Welcome back!", Toast.LENGTH_SHORT).show();
            showLoading(true);
            new Handler(Looper.getMainLooper()).postDelayed(() -> performLogin(email), 1000);
            return;
        }

        // Check if user has registered before
        if (secureStorage != null) {
            try {
                String registeredEmail = secureStorage.getString("registered_email", "");
                String registeredPassword = secureStorage.getString("registered_password", "");

                if (!registeredEmail.isEmpty() && email.equals(registeredEmail)) {
                    if (password.equals(registeredPassword)) {
                        Toast.makeText(this, "✅ Login Successful! Welcome back!", Toast.LENGTH_SHORT).show();
                        showLoading(true);
                        new Handler(Looper.getMainLooper()).postDelayed(() -> performLogin(email), 1000);
                        return;
                    } else {
                        Toast.makeText(this, "❌ Login Failed: Incorrect password", Toast.LENGTH_SHORT).show();
                        passwordInput.setError("Incorrect password");
                        return;
                    }
                }
            } catch (Exception e) {
                Log.e(TAG, "Error checking stored credentials", e);
            }
        }

        // Email not found
        Toast.makeText(this, "❌ Login Failed: Email not found. Please register first.", Toast.LENGTH_SHORT).show();
        emailInput.setError("Email not found");
    }

    private void handleRegistration() {
        String fullName = fullNameInput.getText().toString().trim();
        String phone = phoneInput.getText().toString().trim();
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();
        String confirmPassword = confirmPasswordInput.getText().toString().trim();

        if (fullName.isEmpty()) {
            fullNameInput.setError("Full name is required");
            Toast.makeText(this, "❌ Please enter your full name", Toast.LENGTH_SHORT).show();
            return;
        }

        if (phone.isEmpty()) {
            phoneInput.setError("Phone number is required");
            Toast.makeText(this, "❌ Please enter your phone number", Toast.LENGTH_SHORT).show();
            return;
        }

        if (email.isEmpty()) {
            emailInput.setError("Email is required");
            Toast.makeText(this, "❌ Please enter your email", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!isValidEmail(email)) {
            emailInput.setError("Invalid email format (e.g. user@example.com)");
            Toast.makeText(this, "❌ Invalid email format", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.isEmpty()) {
            passwordInput.setError("Password is required");
            Toast.makeText(this, "❌ Please enter a password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (password.length() < 6) {
            passwordInput.setError("Password must be at least 6 characters");
            Toast.makeText(this, "❌ Password must be at least 6 characters", Toast.LENGTH_SHORT).show();
            return;
        }

        if (confirmPassword.isEmpty()) {
            confirmPasswordInput.setError("Please confirm your password");
            Toast.makeText(this, "❌ Please confirm your password", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!password.equals(confirmPassword)) {
            confirmPasswordInput.setError("Passwords do not match");
            Toast.makeText(this, "❌ Passwords do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        Toast.makeText(this, "✅ Registration Successful! Complete your profile!", Toast.LENGTH_SHORT).show();
        showLoading(true);

        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            if (secureStorage != null) {
                try {
                    secureStorage.saveString("registered_email", email);
                    secureStorage.saveString("registered_password", password);
                    secureStorage.saveString("registered_name", fullName);
                    secureStorage.saveString("registered_phone", phone);
                    secureStorage.saveBoolean("onboarding_completed", false);
                } catch (Exception e) {
                    Log.e(TAG, "Error saving registration", e);
                }
            }

            // Launch onboarding for new users
            launchOnboarding(email);
        }, 1000);
    }

    private boolean isValidEmail(String email) {
        return email != null && Patterns.EMAIL_ADDRESS.matcher(email).matches();
    }

    private void launchOnboarding(String email) {
        try {
            if (secureStorage != null) {
                secureStorage.saveString("user_email", email);
                secureStorage.saveString(SecureStorage.KEY_USER_ID, "user_" + System.currentTimeMillis());
            }

            showLoading(false);

            Log.d(TAG, "Launching onboarding");
            Intent intent = new Intent(this, com.glorymukami.neobanking.ui.onboarding.OnboardingActivity.class);
            startActivity(intent);
            finish();

        } catch (Exception e) {
            Log.e(TAG, "Error launching onboarding, going to main", e);
            Toast.makeText(this, "⚠️ Skipping onboarding", Toast.LENGTH_SHORT).show();
            performLogin(email);
        }
    }

    private void performLogin(String email) {
        try {
            if (secureStorage != null) {
                secureStorage.saveBoolean(SecureStorage.KEY_IS_LOGGED_IN, true);
                secureStorage.saveString("user_email", email);
                secureStorage.saveString(SecureStorage.KEY_USER_ID, "user_" + System.currentTimeMillis());
            }

            showLoading(false);

            Intent intent = new Intent(this, MainActivity.class);
            startActivity(intent);
            finish();

        } catch (Exception e) {
            Log.e(TAG, "Error in performLogin", e);
            Toast.makeText(this, "❌ Navigation error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            showLoading(false);
        }
    }

    private void showLoading(boolean show) {
        progressBar.setVisibility(show ? View.VISIBLE : View.GONE);
        loginButton.setEnabled(!show);
        registerButton.setEnabled(!show);
        switchModeButton.setEnabled(!show);
        emailInput.setEnabled(!show);
        passwordInput.setEnabled(!show);
        confirmPasswordInput.setEnabled(!show);
        fullNameInput.setEnabled(!show);
        phoneInput.setEnabled(!show);
    }
}