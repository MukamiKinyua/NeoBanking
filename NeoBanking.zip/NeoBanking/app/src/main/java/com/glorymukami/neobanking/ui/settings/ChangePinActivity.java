package com.glorymukami.neobanking.ui.settings;

import android.os.Bundle;
import android.text.InputFilter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.utils.SecureStorage;

public class ChangePinActivity extends AppCompatActivity {

    private EditText currentPinInput;
    private EditText newPinInput;
    private EditText confirmPinInput;
    private Button saveButton;
    private SecureStorage secureStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_pin);

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Change PIN");
        }

        initViews();
        setupListeners();
    }

    private void initViews() {
        currentPinInput = findViewById(R.id.current_pin_input);
        newPinInput = findViewById(R.id.new_pin_input);
        confirmPinInput = findViewById(R.id.confirm_pin_input);
        saveButton = findViewById(R.id.save_button);

        // Set PIN length to 4 digits
        InputFilter[] filters = new InputFilter[]{new InputFilter.LengthFilter(4)};
        currentPinInput.setFilters(filters);
        newPinInput.setFilters(filters);
        confirmPinInput.setFilters(filters);

        try {
            secureStorage = new SecureStorage(this);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void setupListeners() {
        saveButton.setOnClickListener(v -> handlePinChange());
    }

    private void handlePinChange() {
        String currentPin = currentPinInput.getText().toString().trim();
        String newPin = newPinInput.getText().toString().trim();
        String confirmPin = confirmPinInput.getText().toString().trim();

        // Validate current PIN
        if (currentPin.isEmpty()) {
            currentPinInput.setError("Current PIN is required");
            Toast.makeText(this, "❌ Please enter current PIN", Toast.LENGTH_SHORT).show();
            return;
        }

        if (currentPin.length() != 4) {
            currentPinInput.setError("PIN must be 4 digits");
            Toast.makeText(this, "❌ PIN must be exactly 4 digits", Toast.LENGTH_SHORT).show();
            return;
        }

        // Verify current PIN
        if (secureStorage != null) {
            try {
                String storedPin = secureStorage.getString("user_pin", "");
                if (!storedPin.isEmpty() && !currentPin.equals(storedPin)) {
                    currentPinInput.setError("Incorrect current PIN");
                    Toast.makeText(this, "❌ Current PIN is incorrect", Toast.LENGTH_SHORT).show();
                    return;
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        }

        // Validate new PIN
        if (newPin.isEmpty()) {
            newPinInput.setError("New PIN is required");
            Toast.makeText(this, "❌ Please enter new PIN", Toast.LENGTH_SHORT).show();
            return;
        }

        if (newPin.length() != 4) {
            newPinInput.setError("PIN must be 4 digits");
            Toast.makeText(this, "❌ PIN must be exactly 4 digits", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!newPin.matches("\\d{4}")) {
            newPinInput.setError("PIN must contain only numbers");
            Toast.makeText(this, "❌ PIN must contain only numbers", Toast.LENGTH_SHORT).show();
            return;
        }

        if (newPin.equals(currentPin)) {
            newPinInput.setError("New PIN must be different");
            Toast.makeText(this, "❌ New PIN must be different from current", Toast.LENGTH_SHORT).show();
            return;
        }

        // Validate confirm PIN
        if (confirmPin.isEmpty()) {
            confirmPinInput.setError("Please confirm new PIN");
            Toast.makeText(this, "❌ Please confirm new PIN", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!newPin.equals(confirmPin)) {
            confirmPinInput.setError("PINs do not match");
            Toast.makeText(this, "❌ PINs do not match", Toast.LENGTH_SHORT).show();
            return;
        }

        // Save new PIN
        if (secureStorage != null) {
            try {
                secureStorage.saveString("user_pin", newPin);
                Toast.makeText(this, "✅ PIN changed successfully!", Toast.LENGTH_LONG).show();
                finish();
            } catch (Exception e) {
                Toast.makeText(this, "❌ Error saving PIN: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        } else {
            Toast.makeText(this, "✅ PIN changed successfully!", Toast.LENGTH_SHORT).show();
            finish();
        }
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}