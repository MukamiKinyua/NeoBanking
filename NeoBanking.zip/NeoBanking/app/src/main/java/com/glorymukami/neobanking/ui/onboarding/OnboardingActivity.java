package com.glorymukami.neobanking.ui.onboarding;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.*;
import androidx.appcompat.app.AppCompatActivity;
import androidx.viewpager2.widget.ViewPager2;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.ui.main.MainActivity;
import com.glorymukami.neobanking.utils.SecureStorage;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;

/**
 * Comprehensive onboarding flow for new bank account
 * Collects all KYC information in multi-step form
 */
public class OnboardingActivity extends AppCompatActivity {

    private static final String TAG = "OnboardingActivity";
    private static final int PICK_ID_IMAGE = 1;
    private static final int PICK_ADDRESS_PROOF = 2;
    private static final int PICK_INCOME_PROOF = 3;
    private static final int CAPTURE_SELFIE = 4;

    private ViewPager2 viewPager;
    private TabLayout tabLayout;
    private MaterialButton nextButton;
    private MaterialButton prevButton;
    private MaterialButton submitButton;
    private ProgressBar progressBar;

    private OnboardingPagerAdapter adapter;
    private SecureStorage secureStorage;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_onboarding);

        try {
            secureStorage = new SecureStorage(this);
            initViews();
            setupViewPager();
            setupListeners();

            Toast.makeText(this, "📋 Complete your profile to get started", Toast.LENGTH_LONG).show();

        } catch (Exception e) {
            Log.e(TAG, "Error initializing onboarding", e);
            Toast.makeText(this, "❌ Error: " + e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private void initViews() {
        viewPager = findViewById(R.id.onboarding_viewpager);
        tabLayout = findViewById(R.id.onboarding_tabs);
        nextButton = findViewById(R.id.next_button);
        prevButton = findViewById(R.id.prev_button);
        submitButton = findViewById(R.id.submit_button);
        progressBar = findViewById(R.id.progress_bar);
    }

    private void setupViewPager() {
        adapter = new OnboardingPagerAdapter(this);
        viewPager.setAdapter(adapter);

        // Link tabs with ViewPager
        new TabLayoutMediator(tabLayout, viewPager,
                (tab, position) -> tab.setText(adapter.getPageTitle(position))
        ).attach();

        // Disable user swiping
        viewPager.setUserInputEnabled(false);

        updateButtonVisibility(0);
    }

    private void setupListeners() {
        nextButton.setOnClickListener(v -> {
            if (validateCurrentPage()) {
                int currentItem = viewPager.getCurrentItem();
                if (currentItem < adapter.getItemCount() - 1) {
                    viewPager.setCurrentItem(currentItem + 1);
                    updateButtonVisibility(currentItem + 1);
                    Toast.makeText(this, "✅ Page " + (currentItem + 1) + " completed", Toast.LENGTH_SHORT).show();
                }
            }
        });

        prevButton.setOnClickListener(v -> {
            int currentItem = viewPager.getCurrentItem();
            if (currentItem > 0) {
                viewPager.setCurrentItem(currentItem - 1);
                updateButtonVisibility(currentItem - 1);
                Toast.makeText(this, "⬅️ Back to previous page", Toast.LENGTH_SHORT).show();
            }
        });

        submitButton.setOnClickListener(v -> {
            if (validateCurrentPage()) {
                submitOnboarding();
            }
        });
    }

    private void updateButtonVisibility(int position) {
        prevButton.setVisibility(position > 0 ? View.VISIBLE : View.GONE);

        if (position == adapter.getItemCount() - 1) {
            nextButton.setVisibility(View.GONE);
            submitButton.setVisibility(View.VISIBLE);
        } else {
            nextButton.setVisibility(View.VISIBLE);
            submitButton.setVisibility(View.GONE);
        }
    }

    private boolean validateCurrentPage() {
        int currentPage = viewPager.getCurrentItem();

        // Get current fragment and validate
        OnboardingPageFragment fragment = adapter.getFragment(currentPage);
        if (fragment != null) {
            return fragment.validatePage();
        }

        return true;
    }

    private void submitOnboarding() {
        Toast.makeText(this, "⏳ Submitting application...", Toast.LENGTH_SHORT).show();
        progressBar.setVisibility(View.VISIBLE);
        nextButton.setEnabled(false);
        prevButton.setEnabled(false);
        submitButton.setEnabled(false);

        // Simulate submission delay
        new android.os.Handler().postDelayed(() -> {
            try {
                // Save onboarding completion
                secureStorage.saveBoolean("onboarding_completed", true);

                Toast.makeText(this, "✅ Application submitted successfully!", Toast.LENGTH_LONG).show();

                // Navigate to main app
                Intent intent = new Intent(OnboardingActivity.this, MainActivity.class);
                intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
                finish();

            } catch (Exception e) {
                Log.e(TAG, "Error submitting onboarding", e);
                Toast.makeText(this, "❌ Submission failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                progressBar.setVisibility(View.GONE);
                submitButton.setEnabled(true);
            }
        }, 2000);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if (resultCode == RESULT_OK && data != null) {
            try {
                Uri imageUri = data.getData();
                String message = "";

                switch (requestCode) {
                    case PICK_ID_IMAGE:
                        message = "✅ ID document uploaded successfully";
                        break;
                    case PICK_ADDRESS_PROOF:
                        message = "✅ Address proof uploaded successfully";
                        break;
                    case PICK_INCOME_PROOF:
                        message = "✅ Income proof uploaded successfully";
                        break;
                    case CAPTURE_SELFIE:
                        message = "✅ Selfie captured successfully";
                        break;
                }

                Toast.makeText(this, message, Toast.LENGTH_SHORT).show();

            } catch (Exception e) {
                Log.e(TAG, "Error handling image", e);
                Toast.makeText(this, "❌ Error uploading image", Toast.LENGTH_SHORT).show();
            }
        }
    }
}