package com.glorymukami.neobanking.utils;

import com.glorymukami.neobanking.models.Transaction;
import java.util.ArrayList;
import java.util.List;

/**
 * Generates dummy transaction data matching the Budget charts
 * Based on the chart showing:
 * - Food & Dining: $450
 * - Transportation: $300
 * - Entertainment: $200
 * - Shopping: $150
 * - Bills & Utilities: $400
 * - Healthcare: $100
 *
 * Monthly trend: $1,200, $1,500, $1,300, $1,600, $1,400, $1,600
 */
public class DummyData {

    public static List<Transaction> getTransactions() {
        List<Transaction> transactions = new ArrayList<>();

        // INCOME TRANSACTIONS
        transactions.add(new Transaction("1", "Salary Payment", "Income", 3500.00, "income", "2024-12-01", "Monthly salary"));
        transactions.add(new Transaction("2", "Freelance Project", "Income", 800.00, "income", "2024-12-15", "Web design project"));

        // EXPENSE TRANSACTIONS - Food & Dining ($450 total)
        transactions.add(new Transaction("3", "Grocery Shopping", "Food & Dining", 120.00, "expense", "2024-12-05", "Weekly groceries"));
        transactions.add(new Transaction("4", "Restaurant Dinner", "Food & Dining", 85.00, "expense", "2024-12-08", "Dinner with friends"));
        transactions.add(new Transaction("5", "Coffee Shop", "Food & Dining", 25.00, "expense", "2024-12-10", "Morning coffee"));
        transactions.add(new Transaction("6", "Lunch Delivery", "Food & Dining", 45.00, "expense", "2024-12-12", "Food delivery"));
        transactions.add(new Transaction("7", "Fast Food", "Food & Dining", 30.00, "expense", "2024-12-14", "Quick lunch"));
        transactions.add(new Transaction("8", "Grocery Shopping", "Food & Dining", 145.00, "expense", "2024-12-18", "Monthly stock up"));

        // EXPENSE TRANSACTIONS - Transportation ($300 total)
        transactions.add(new Transaction("9", "Gas Station", "Transportation", 60.00, "expense", "2024-12-03", "Fuel"));
        transactions.add(new Transaction("10", "Uber Rides", "Transportation", 45.00, "expense", "2024-12-06", "Multiple trips"));
        transactions.add(new Transaction("11", "Car Maintenance", "Transportation", 120.00, "expense", "2024-12-11", "Oil change"));
        transactions.add(new Transaction("12", "Parking Fee", "Transportation", 25.00, "expense", "2024-12-13", "City parking"));
        transactions.add(new Transaction("13", "Gas Station", "Transportation", 50.00, "expense", "2024-12-19", "Fuel"));

        // EXPENSE TRANSACTIONS - Entertainment ($200 total)
        transactions.add(new Transaction("14", "Movie Tickets", "Entertainment", 45.00, "expense", "2024-12-07", "Cinema"));
        transactions.add(new Transaction("15", "Streaming Services", "Entertainment", 35.00, "expense", "2024-12-01", "Netflix + Spotify"));
        transactions.add(new Transaction("16", "Concert Tickets", "Entertainment", 80.00, "expense", "2024-12-15", "Live music"));
        transactions.add(new Transaction("17", "Gaming", "Entertainment", 40.00, "expense", "2024-12-20", "New game purchase"));

        // EXPENSE TRANSACTIONS - Shopping ($150 total)
        transactions.add(new Transaction("18", "Clothing", "Shopping", 85.00, "expense", "2024-12-09", "New shirt and jeans"));
        transactions.add(new Transaction("19", "Online Shopping", "Shopping", 45.00, "expense", "2024-12-16", "Electronics accessories"));
        transactions.add(new Transaction("20", "Books", "Shopping", 20.00, "expense", "2024-12-21", "Novel purchase"));

        // EXPENSE TRANSACTIONS - Bills & Utilities ($400 total)
        transactions.add(new Transaction("21", "Electricity Bill", "Bills & Utilities", 120.00, "expense", "2024-12-02", "Monthly electricity"));
        transactions.add(new Transaction("22", "Internet Bill", "Bills & Utilities", 60.00, "expense", "2024-12-02", "Broadband"));
        transactions.add(new Transaction("23", "Water Bill", "Bills & Utilities", 40.00, "expense", "2024-12-02", "Water supply"));
        transactions.add(new Transaction("24", "Phone Bill", "Bills & Utilities", 50.00, "expense", "2024-12-02", "Mobile plan"));
        transactions.add(new Transaction("25", "Rent Payment", "Bills & Utilities", 130.00, "expense", "2024-12-01", "Monthly rent"));

        // EXPENSE TRANSACTIONS - Healthcare ($100 total)
        transactions.add(new Transaction("26", "Pharmacy", "Healthcare", 45.00, "expense", "2024-12-04", "Prescription medicine"));
        transactions.add(new Transaction("27", "Doctor Visit", "Healthcare", 55.00, "expense", "2024-12-17", "Check-up"));

        return transactions;
    }

    public static double getTotalIncome() {
        double total = 0;
        for (Transaction t : getTransactions()) {
            if (t.isIncome()) {
                total += t.getAmount();
            }
        }
        return total;
    }

    public static double getTotalExpenses() {
        double total = 0;
        for (Transaction t : getTransactions()) {
            if (t.isExpense()) {
                total += t.getAmount();
            }
        }
        return total;
    }

    public static double getBalance() {
        return getTotalIncome() - getTotalExpenses();
    }

    public static double getCategoryTotal(String category) {
        double total = 0;
        for (Transaction t : getTransactions()) {
            if (t.getCategory().equalsIgnoreCase(category) && t.isExpense()) {
                total += t.getAmount();
            }
        }
        return total;
    }
}