package com.glorymukami.neobanking.ui.settings;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import com.glorymukami.neobanking.R;

public class SettingsActivity extends AppCompatActivity {

    private Button changePasswordButton;
    private Button changePinButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Toast.makeText(this, "⚙️ Settings page loaded", Toast.LENGTH_SHORT).show();

        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Settings");
        }

        initViews();
        setupListeners();
    }

    private void initViews() {
        changePasswordButton = findViewById(R.id.change_password_button);
        changePinButton = findViewById(R.id.change_pin_button);
    }

    private void setupListeners() {
        changePasswordButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChangePasswordActivity.class);
            startActivity(intent);
            Toast.makeText(this, "🔐 Opening Change Password", Toast.LENGTH_SHORT).show();
        });

        changePinButton.setOnClickListener(v -> {
            Intent intent = new Intent(this, ChangePinActivity.class);
            startActivity(intent);
            Toast.makeText(this, "🔢 Opening Change PIN", Toast.LENGTH_SHORT).show();
        });
    }

    @Override
    public boolean onSupportNavigateUp() {
        finish();
        return true;
    }
}