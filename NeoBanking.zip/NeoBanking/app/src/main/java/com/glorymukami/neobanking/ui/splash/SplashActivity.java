package com.glorymukami.neobanking.ui.splash;

import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import androidx.appcompat.app.AppCompatActivity;
import com.glorymukami.neobanking.ui.auth.AuthActivity;
import com.glorymukami.neobanking.ui.main.MainActivity;
import com.glorymukami.neobanking.utils.SecureStorage;

/**
 * Splash screen shown on app launch
 * Checks authentication status and navigates accordingly
 */
public class SplashActivity extends AppCompatActivity {

    private static final String TAG = "SplashActivity";
    private static final int SPLASH_DELAY = 2000; // 2 seconds

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Note: No setContentView() needed - using windowBackground from theme

        // Delay and check authentication
        new Handler(Looper.getMainLooper()).postDelayed(() -> {
            checkAuthAndNavigate();
        }, SPLASH_DELAY);
    }

    /**
     * Check if user is logged in and navigate
     */
    private void checkAuthAndNavigate() {
        boolean isLoggedIn = false;

        try {
            SecureStorage secureStorage = new SecureStorage(this);
            isLoggedIn = secureStorage.getBoolean(SecureStorage.KEY_IS_LOGGED_IN, false);
        } catch (Exception e) {
            Log.e(TAG, "Error checking login status, assuming not logged in", e);
            isLoggedIn = false;
        }

        Intent intent;
        if (isLoggedIn) {
            // User is logged in, go to main screen
            intent = new Intent(this, MainActivity.class);
        } else {
            // User not logged in, go to auth screen
            intent = new Intent(this, AuthActivity.class);
        }

        startActivity(intent);
        finish();
    }
}