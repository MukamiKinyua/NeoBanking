package com.glorymukami.neobanking.ui.main;

import android.os.Bundle;
import android.util.Log;
import android.widget.Toast;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import com.glorymukami.neobanking.R;
import com.glorymukami.neobanking.ui.home.HomeFragment;
import com.glorymukami.neobanking.ui.transactions.TransactionsFragment;
import com.glorymukami.neobanking.ui.budget.BudgetFragment;
import com.glorymukami.neobanking.ui.chatbot.ChatbotFragment;
import com.glorymukami.neobanking.ui.profile.ProfileFragment;
import com.google.android.material.bottomnavigation.BottomNavigationView;

/**
 * Main activity with bottom navigation including AI Chatbot
 */
public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private BottomNavigationView bottomNav;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        Log.d(TAG, "onCreate() started");

        try {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);

            bottomNav = findViewById(R.id.bottom_navigation);
            if (bottomNav == null) {
                Log.e(TAG, "bottom_navigation is null!");
                Toast.makeText(this, "❌ Error loading main screen", Toast.LENGTH_LONG).show();
                return;
            }

            bottomNav.setOnItemSelectedListener(item -> {
                try {
                    int itemId = item.getItemId();
                    Fragment selectedFragment = null;
                    String tabName = "";

                    if (itemId == R.id.nav_home) {
                        selectedFragment = new HomeFragment();
                        tabName = "Home";
                    } else if (itemId == R.id.nav_transactions) {
                        selectedFragment = new TransactionsFragment();
                        tabName = "Transactions";
                    } else if (itemId == R.id.nav_budget) {
                        selectedFragment = new BudgetFragment();
                        tabName = "Budget & Charts";
                    } else if (itemId == R.id.nav_chatbot) {
                        selectedFragment = new ChatbotFragment();
                        tabName = "AI Chatbot";
                    } else if (itemId == R.id.nav_profile) {
                        selectedFragment = new ProfileFragment();
                        tabName = "Profile";
                    }

                    if (selectedFragment != null) {
                        try {
                            getSupportFragmentManager().beginTransaction()
                                    .replace(R.id.fragment_container, selectedFragment)
                                    .commit();
                            Toast.makeText(MainActivity.this,
                                    "✅ " + tabName + " loaded successfully!",
                                    Toast.LENGTH_SHORT).show();
                        } catch (Exception e) {
                            Log.e(TAG, "Error replacing fragment", e);
                            Toast.makeText(MainActivity.this,
                                    "❌ Error loading " + tabName,
                                    Toast.LENGTH_SHORT).show();
                        }
                    }

                    return true;

                } catch (Exception e) {
                    Log.e(TAG, "Error in navigation listener", e);
                    Toast.makeText(MainActivity.this, "❌ Navigation error", Toast.LENGTH_SHORT).show();
                    return false;
                }
            });

            // Load default fragment
            if (savedInstanceState == null) {
                try {
                    getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_container, new HomeFragment())
                            .commit();
                    Toast.makeText(this, "✅ Welcome to NeoBanking!", Toast.LENGTH_SHORT).show();
                } catch (Exception e) {
                    Log.e(TAG, "Error loading default fragment", e);
                    Toast.makeText(this, "❌ Error loading home screen", Toast.LENGTH_SHORT).show();
                }
            }

            Log.d(TAG, "onCreate() completed successfully");

        } catch (Exception e) {
            Log.e(TAG, "FATAL ERROR in onCreate()", e);
            Toast.makeText(this, "❌ Fatal error: " + e.getMessage(), Toast.LENGTH_LONG).show();
            e.printStackTrace();
        }
    }
}