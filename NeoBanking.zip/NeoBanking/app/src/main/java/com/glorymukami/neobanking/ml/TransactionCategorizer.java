package com.glorymukami.neobanking.ml;

import android.content.Context;
import android.util.Log;
import com.glorymukami.neobanking.data.local.entities.Transaction;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

/**
 * ML-based transaction categorization
 * Uses pattern matching and keyword analysis
 * In production, this would use TensorFlow Lite model
 */
public class TransactionCategorizer {

    private static final String TAG = "TransactionCategorizer";
    private Context context;

    // Category keywords (in production, this would be ML model)
    private static final Map<String, String[]> CATEGORY_KEYWORDS = new HashMap<>();

    static {
        CATEGORY_KEYWORDS.put("FOOD", new String[]{
                "restaurant", "cafe", "coffee", "food", "grocery", "market",
                "pizza", "burger", "sushi", "starbucks", "mcdonald", "subway"
        });

        CATEGORY_KEYWORDS.put("TRANSPORT", new String[]{
                "uber", "lyft", "taxi", "gas", "fuel", "parking", "metro",
                "transit", "train", "airline", "flight", "car rental"
        });

        CATEGORY_KEYWORDS.put("SHOPPING", new String[]{
                "amazon", "walmart", "target", "store", "shop", "retail",
                "clothing", "apparel", "nike", "adidas", "mall"
        });

        CATEGORY_KEYWORDS.put("ENTERTAINMENT", new String[]{
                "netflix", "spotify", "movie", "cinema", "theater", "game",
                "concert", "entertainment", "disney", "hulu", "youtube"
        });

        CATEGORY_KEYWORDS.put("BILLS", new String[]{
                "electric", "water", "internet", "phone", "utility", "insurance",
                "mortgage", "rent", "payment", "bill"
        });

        CATEGORY_KEYWORDS.put("HEALTHCARE", new String[]{
                "pharmacy", "doctor", "hospital", "medical", "health", "clinic",
                "dental", "cvs", "walgreens", "prescription"
        });
    }

    public TransactionCategorizer(Context context) {
        this.context = context;
    }

    /**
     * Categorize a transaction based on description and merchant
     * Returns category and confidence score
     */
    public CategoryResult categorize(Transaction transaction) {
        String description = transaction.getDescription();
        String merchantName = transaction.getMerchantName();

        if (description == null && merchantName == null) {
            return new CategoryResult("OTHER", 0.0f);
        }

        String searchText = ((description != null ? description : "") + " " +
                (merchantName != null ? merchantName : "")).toLowerCase();

        // Find best matching category
        String bestCategory = "OTHER";
        float bestScore = 0.0f;

        for (Map.Entry<String, String[]> entry : CATEGORY_KEYWORDS.entrySet()) {
            String category = entry.getKey();
            String[] keywords = entry.getValue();

            float score = calculateScore(searchText, keywords);
            if (score > bestScore) {
                bestScore = score;
                bestCategory = category;
            }
        }

        // In production, here we would:
        // 1. Load TensorFlow Lite model
        // 2. Preprocess transaction data
        // 3. Run inference
        // 4. Get category predictions with confidence scores

        Log.d(TAG, "Categorized transaction: " + searchText + " -> " + bestCategory + " (confidence: " + bestScore + ")");

        return new CategoryResult(bestCategory, bestScore);
    }

    /**
     * Calculate match score for keywords
     */
    private float calculateScore(String text, String[] keywords) {
        int matches = 0;
        for (String keyword : keywords) {
            if (text.contains(keyword.toLowerCase())) {
                matches++;
            }
        }
        return (float) matches / keywords.length;
    }

    /**
     * Batch categorize multiple transactions
     */
    public void categorizeBatch(Transaction[] transactions) {
        for (Transaction transaction : transactions) {
            CategoryResult result = categorize(transaction);
            transaction.setCategory(result.getCategory());
            transaction.setCategoryConfidence(result.getConfidence());
        }
    }

    /**
     * Result class for categorization
     */
    public static class CategoryResult {
        private String category;
        private float confidence;

        public CategoryResult(String category, float confidence) {
            this.category = category;
            this.confidence = confidence;
        }

        public String getCategory() {
            return category;
        }

        public float getConfidence() {
            return confidence;
        }
    }
}